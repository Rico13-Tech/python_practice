Name="Dorsainvil Ritshi"
Age="27"
print("Mwen rele"+"  "+Name+"  "+"Mwen gen"+"  "+Age+"  "+"Lane")