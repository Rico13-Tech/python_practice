a="coding"
b="Challenge"
print(a+" "+b)