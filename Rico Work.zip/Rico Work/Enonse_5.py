a=2
b=5.5
c="Mwen se ayisyen"
d=["Youse","Djhyne","Steph"]
print(type(d))
print(type(a))
print(type(b))
print(type(c))
